/**
 * 
 */
/**
 * 
 */
module SistemaCalificaciones1 {
	requires java.desktop;
}