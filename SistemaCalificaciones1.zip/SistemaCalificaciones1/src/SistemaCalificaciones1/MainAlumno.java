package SistemaCalificaciones1;

import Vista.VentanaPrincipal;

public class MainAlumno {
    public static void main(String[] args) {
        // Llama directamente a la ventana principal
        VentanaPrincipal.main(args);
    }
}
